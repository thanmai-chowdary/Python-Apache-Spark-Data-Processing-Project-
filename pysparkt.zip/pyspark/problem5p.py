from pyspark.sql import SparkSession
from pyspark.sql.functions import desc
 # Set log level to ERROR to suppress Spark logging
spark = SparkSession.builder \
    .appName("TopRatedMovies") \
    .config("spark.log.level", "ERROR") \
    .getOrCreate()
# Create a SparkSession
spark = SparkSession.builder \
    .appName("Top10RatedMovies") \
    .getOrCreate()
 
# Load the dataset into a DataFrame
df = spark.read.csv("C:/Users/User/OneDrive/Desktop/ratings.csv", header=True, inferSchema=True)
 
# Group by movie and count ratings for each movie
movie_ratings_count = df.groupBy("movieId").count()
 
# Sort the movies by the count of ratings in descending order
top_10_movies = movie_ratings_count.orderBy(desc("count")).limit(10)
 
# Show the results
top_10_movies.show()
 
# Stop the SparkSession
spark.stop()