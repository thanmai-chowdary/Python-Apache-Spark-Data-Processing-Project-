import os
import sys
import logging
from pyspark.sql import SparkSession
from pyspark.sql.functions import col

# Suppress unnecessary Spark logging
logging.getLogger("py4j").setLevel(logging.ERROR)
logging.getLogger("pyspark").setLevel(logging.ERROR)

# Redirect stdout and stderr to /dev/null
sys.stdout = open(os.devnull, 'w')
sys.stderr = open(os.devnull, 'w')

# Create a SparkSession
spark = SparkSession.builder \
    .appName("TopRatedMovies") \
    .config("spark.log.level", "ERROR") \
    .getOrCreate()

# Load data
data = spark.read.csv("C:/Users/User/Downloads/u.data", sep="\t", inferSchema=True) \
           .toDF("user_id", "movie_id", "rating")

# Filter movies with at least 30 ratings
popular_movies = data.groupBy("movie_id").count().filter(col("count") >= 30)

# Join with original data to get movie titles
popular_movies_with_titles = popular_movies.join(data.select("movie_id", "rating"), "movie_id", "inner")

# Count ratings for each movie
movie_ratings_count = popular_movies_with_titles.groupBy("movie_id").count()

# Sort movies by count of ratings
sorted_movies = movie_ratings_count.orderBy(col("count").desc())

# Get top five movies
top_five_movies = sorted_movies.limit(5)

# Show the top five movies
top_five_movies.show()

# Stop SparkSession
spark.stop()
