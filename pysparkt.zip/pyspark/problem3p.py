from pyspark.sql import SparkSession
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, DateType
from pyspark.sql.functions import to_date, month, max, regexp_replace
import pandas as pd
from tabulate import tabulate
spark = SparkSession.builder\
   .appName("ReadCSV")\
   .getOrCreate()
schema =StructType([
       StructField("Station_ID", StringType(), True),
       StructField("Date", IntegerType(), True),
       StructField("Element", StringType(), True),
       StructField("Observation_Value",IntegerType(), True),
       StructField("Details", StringType(), True)
])
df = spark.read.csv("C:/Users/User/Downloads/temp1800 (1).csv", header=False, schema=schema)
df = df.withColumn("Date", to_date(df["Date"].cast("string"), "yyyyMMdd"))
df = df.withColumn("Month", month(df["Date"]))
df = df.withColumn("Date", regexp_replace(df["Date"], "-", ""))
months = ['Jan', 'Apr', 'Jul', 'Oct']
temperature = []
date = []
station_name = []
data=[]
for month in [1, 4, 7, 10]:
       max_temp_row = df.filter((df["Month"] == month) & (df["Element"] == "TMAX")).agg(max("Observation_Value")).collect()[0]
       max_temp = max_temp_row[0]
       max_temp_record = df.filter((df["Month"] == month) & (df["Element"] == "TMAX") & (df["Observation_Value"] == max_temp)).first()
       date.append(max_temp_record["Date"]) 
       station_name.append(max_temp_record["Station_ID"])
       temperature.append(max_temp)
data = {
    "Month": months,
    "Temperature": temperature,
    "Date": date,
    "Station_Name": station_name
}
df_output = pd.DataFrame(data)
df_output = df_output.transpose()
print(tabulate(df_output, headers='firstrow', tablefmt='grid'))
spark.stop()