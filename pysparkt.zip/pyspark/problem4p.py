from pyspark.sql import SparkSession
from pyspark.sql.functions import count as spark_count, sum as spark_sum

# Set log level to ERROR to suppress Spark logging
spark = SparkSession.builder \
    .appName("Customer Order Analysis") \
    .config("spark.log.level", "ERROR") \
    .getOrCreate()

# Read CSV file into Spark DataFrame
df = spark.read.csv('C:/Users/User/Downloads/orders.csv', header=False, inferSchema=True) \
    .toDF('customer_id', 'item_id', 'price')

# Group data by customer ID and calculate the total spending for each customer
df_customer_spend = df.groupBy('customer_id').agg(spark_sum('price').alias('total_spending')) \
    .orderBy('total_spending', ascending=False)

# Show top 5 customers with their spending total
print("Top 5 customers with their spending total (sorted by decreasing total spending):")
df_customer_spend.show(5, truncate=False)

# Group data by item ID and calculate the count for each item
df_item_freq = df.groupBy('item_id').agg(spark_count('item_id').alias('frequency')) \
    .orderBy('frequency', ascending=False)

# Find the item ID that was purchased most frequently
most_frequent_item_id = df_item_freq.first()['item_id']
print("\nItem ID that was purchased most frequently:", most_frequent_item_id)

# Group data by item ID and calculate the total price for each item
df_item_price_total = df.groupBy('item_id').agg(spark_sum('price').alias('total_price')) \
    .orderBy('total_price', ascending=False)

# Find the item ID that has the highest total price
highest_total_price_item_id = df_item_price_total.first()['item_id']
print("Item ID that has the highest total price:", highest_total_price_item_id)

# Stop SparkSession
spark.stop()
